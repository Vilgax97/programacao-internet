// Exercício 1: Triângulo
function checkTriangle() {
    const side1 = parseFloat(document.getElementById('side1').value);
    const side2 = parseFloat(document.getElementById('side2').value);
    const side3 = parseFloat(document.getElementById('side3').value);
    const result = document.getElementById('triangleResult');

    if (side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1) {
        if (side1 === side2 && side2 === side3) {
            result.textContent = "Triângulo Equilátero";
        } else if (side1 === side2 || side1 === side3 || side2 === side3) {
            result.textContent = "Triângulo Isósceles";
        } else {
            result.textContent = "Triângulo Escaleno";
        }
    } else {
        result.textContent = "Não forma um triângulo";
    }
}

// Exercício 2: IMC
function calculateIMC() {
    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value);
    const result = document.getElementById('imcResult');
    
    const imc = weight / (height * height);
    let classification;
    
    if (imc < 18.5) classification = "Abaixo do peso";
    else if (imc < 25) classification = "Peso normal";
    else if (imc < 30) classification = "Sobrepeso";
    else if (imc < 35) classification = "Obesidade grau 1";
    else if (imc < 40) classification = "Obesidade grau 2";
    else classification = "Obesidade grau 3";
    
    result.textContent = `IMC: ${imc.toFixed(2)} - ${classification}`;
}

// Exercício 3: Imposto de Veículo
function calculateTax() {
    const year = parseInt(document.getElementById('carYear').value);
    const value = parseFloat(document.getElementById('carValue').value);
    const result = document.getElementById('taxResult');
    
    const rate = year < 1990 ? 0.01 : 0.015;
    const tax = value * rate;
    
    result.textContent = `Imposto: R$${tax.toFixed(2)} (${rate*100}%)`;
}

// Exercício 4: Aumento Salarial
function calculateSalary() {
    const salary = parseFloat(document.getElementById('currentSalary').value);
    const jobCode = document.getElementById('jobCode').value;
    const result = document.getElementById('salaryResult');
    
    let increase;
    switch(jobCode) {
        case '101': increase = 0.10; break;
        case '102': increase = 0.20; break;
        case '103': increase = 0.30; break;
        default: increase = 0.40;
    }
    
    const newSalary = salary * (1 + increase);
    result.textContent = `Novo salário: R$${newSalary.toFixed(2)} (Aumento de ${increase*100}%)`;
}

// Exercício 5: Crédito Bancário
function calculateCredit() {
    const balance = parseFloat(document.getElementById('averageBalance').value);
    const result = document.getElementById('creditResult');
    
    let rate;
    if (balance <= 200) rate = 0;
    else if (balance <= 400) rate = 0.20;
    else if (balance <= 600) rate = 0.30;
    else rate = 0.40;
    
    const credit = balance * rate;
    result.textContent = rate === 0 ? "Sem crédito" : `Crédito: R$${credit.toFixed(2)} (${rate*100}%)`;
}

// Exercício 6: Lanchonete
function calculateSnack() {
    const price = parseFloat(document.getElementById('snackItem').value);
    const quantity = parseInt(document.getElementById('snackQuantity').value);
    const result = document.getElementById('snackResult');
    
    result.textContent = `Total: R$${(price * quantity).toFixed(2)}`;
}

// Exercício 7: Vendas
function calculatePayment() {
    const price = parseFloat(document.getElementById('productPrice').value);
    const method = document.getElementById('paymentMethod').value;
    const result = document.getElementById('salesResult');
    
    let total;
    switch(method) {
        case 'a': total = price * 0.90; break;
        case 'b': total = price * 0.85; break;
        case 'c': total = price; break;
        case 'd': total = price * 1.10; break;
    }
    
    result.textContent = `Total a pagar: R$${total.toFixed(2)}`;
}

// Exercício 8: Professores
function calculateTeacherSalary() {
    const level = parseInt(document.getElementById('teacherLevel').value);
    const hours = parseInt(document.getElementById('hoursWorked').value);
    const result = document.getElementById('teacherResult');
    
    let hourValue;
    switch(level) {
        case 1: hourValue = 12.00; break;
        case 2: hourValue = 17.00; break;
        case 3: hourValue = 25.00; break;
    }
    
    const salary = hourValue * hours * 4.5;
    result.textContent = `Salário: R$${salary.toFixed(2)}`;
}