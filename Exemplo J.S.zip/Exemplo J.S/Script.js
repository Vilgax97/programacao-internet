let titulo = document.querySelector("#titulo");
let CampoTexto = document.querySelector("#CampoTexto");
let btTrocarTexto = document.querySelector("#btTrocarTexto");