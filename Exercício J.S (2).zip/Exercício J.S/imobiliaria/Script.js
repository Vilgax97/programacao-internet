document.querySelector("formTerreno").addEventListener("submit", function(event) {
    event.preventDefault();
  
    let largura = parseFloat(document.querySelector("largura").value);
    let comprimento = parseFloat(document.querySelector("comprimento").value);
  
    if (largura > 0 && comprimento > 0) {
      let area = largura * comprimento;
      document.querySelector("resultado").innerHTML = `
        <p>A área do terreno é <strong>${area.toFixed(2)} m²</strong>.</p>
      `;
    } else {
      document.querySelector("resultado").innerHTML = `
        <p style="color:red;">Insira valores válidos para largura e comprimento.</p>
      `;
    }
  });