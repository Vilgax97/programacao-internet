// Exercício 1: Triângulo
function checkTriangle() {
    let side1 = parseFloat(document.querySelector('#side1').value);
    let side2 = parseFloat(document.querySelector('#side2').value);
    let side3 = parseFloat(document.querySelector('#side3').value);
    let result = document.querySelector('#triangleResult');

    if (side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1) {
        if (side1 === side2 && side2 === side3) {
            result.textContent = "Triângulo Equilátero";
        } else if (side1 === side2 || side1 === side3 || side2 === side3) {
            result.textContent = "Triângulo Isósceles";
        } else {
            result.textContent = "Triângulo Escaleno";
        }
    } else {
        result.textContent = "Não forma um triângulo";
    }
}

// Exercício 2: IMC
function calculateIMC() {
    let weight = parseFloat(document.querySelector('#weight').value);
    let height = parseFloat(document.querySelector('#height').value);
    let result = document.querySelector('#imcResult');
    
    let imc = weight / (height * height);
    let classification;
    
    if (imc < 18.5) classification = "Abaixo do peso";
    else if (imc < 25) classification = "Peso normal";
    else if (imc < 30) classification = "Sobrepeso";
    else if (imc < 35) classification = "Obesidade grau 1";
    else if (imc < 40) classification = "Obesidade grau 2";
    else classification = "Obesidade grau 3";
    
    result.textContent = `IMC: ${imc.toFixed(2)} - ${classification}`;
}

// Exercício 3: Imposto de Veículo
function calculateTax() {
    let year = parseInt(document.querySelector('#carYear').value);
    let value = parseFloat(document.querySelector('#carValue').value);
    let result = document.querySelector('#taxResult');
    
    let rate = year < 1990 ? 0.01 : 0.015;
    let tax = value * rate;
    
    result.textContent = `Imposto: R$${tax.toFixed(2)} (${rate*100}%)`;
}

// Exercício 4: Aumento Salarial Utilizei (switch/case) pois achei que fica melhor
function calculateSalary() {
    let salary = parseFloat(document.querySelector('#currentSalary').value);
    let jobCode = document.querySelector('#jobCode').value;
    let result = document.querySelector('#salaryResult');
    
    let increase;
    switch(jobCode) {
        case '101': increase = 0.10; break;
        case '102': increase = 0.20; break;
        case '103': increase = 0.30; break;
        default: increase = 0.40;
    }
    
    let newSalary = salary * (1 + increase);
    result.textContent = `Novo salário: R$${newSalary.toFixed(2)} (Aumento de ${increase*100}%)`;
}

// Exercício 5: Crédito Bancário
function calculateCredit() {
    let balance = parseFloat(document.querySelector('#averageBalance').value);
    let result = document.querySelector('#creditResult');
    
    let rate;
    if (balance <= 200) rate = 0;
    else if (balance <= 400) rate = 0.20;
    else if (balance <= 600) rate = 0.30;
    else rate = 0.40;
    
    let credit = balance * rate;
    result.textContent = rate === 0 ? "Sem crédito" : `Crédito: R$${credit.toFixed(2)} (${rate*100}%)`;
}

// Exercício 6: Lanchonete
function calculateSnack() {
    let price = parseFloat(document.querySelector('#snackItem').value);
    let quantity = parseInt(document.querySelector('#snackQuantity').value);
    let result = document.querySelector('#snackResult');
    
    result.textContent = `Total: R$${(price * quantity).toFixed(2)}`;
}

// Exercício 7: Vendas Utilizei (switch/case) pois achei que fica melhor
function calculatePayment() {
    let price = parseFloat(document.querySelector('#productPrice').value);
    let method = document.querySelector('#paymentMethod').value;
    let result = document.querySelector('#salesResult');
    
    let total;
    switch(method) {
        case 'a': total = price * 0.90; break;
        case 'b': total = price * 0.85; break;
        case 'c': total = price; break;
        case 'd': total = price * 1.10; break;
    }
    
    result.textContent = `Total a pagar: R$${total.toFixed(2)}`;
}

// Exercício 8: Professores  Utilizei (switch/case) pois achei que fica melhor
function calculateTeacherSalary() {
    let level = parseInt(document.querySelector('#teacherLevel').value);
    let hours = parseInt(document.querySelector('#hoursWorked').value);
    let result = document.querySelector('#teacherResult');
    
    let hourValue;
    switch(level) {
        case 1: hourValue = 12.00; break;
        case 2: hourValue = 17.00; break;
        case 3: hourValue = 25.00; break;
    }
    
    let salary = hourValue * hours * 4.5;
    result.textContent = `Salário: R$${salary.toFixed(2)}`;
}