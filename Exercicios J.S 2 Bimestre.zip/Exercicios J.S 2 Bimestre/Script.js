// Exercício 1 - Cálculo de Troco
function calcularTroco() {
    const valorPago = parseFloat(document.getElementById('valorPago').value);
    const precoProduto = parseFloat(document.getElementById('precoProduto').value);
    const resultado = document.getElementById('resultado1');
    
    if (isNaN(valorPago)) {
        resultado.textContent = "Por favor, insira um valor pago válido.";
        resultado.className = "resultado error";
        return;
    }
    
    if (isNaN(precoProduto)) {
        resultado.textContent = "Por favor, insira um preço de produto válido.";
        resultado.className = "resultado error";
        return;
    }
    
    const troco = valorPago - precoProduto;
    
    if (troco < 0) {
        resultado.textContent = `Dinheiro insuficiente. Faltam R$ ${Math.abs(troco).toFixed(2)}`;
        resultado.className = "resultado error";
    } else {
        resultado.textContent = `Troco: R$ ${troco.toFixed(2)}`;
        resultado.className = "resultado success";
    }
}

// Exercício 2 - Cálculo de Valor por Peso
function calcularValorPorPeso() {
    const precoQuilo = parseFloat(document.getElementById('precoQuilo').value);
    const quantidade = parseFloat(document.getElementById('quantidade').value);
    const resultado = document.getElementById('resultado2');
    
    if (isNaN(precoQuilo) || isNaN(quantidade)) {
        resultado.textContent = "Por favor, insira valores válidos.";
        resultado.className = "resultado error";
        return;
    }
    
    const valorFinal = precoQuilo * quantidade;
    resultado.textContent = `Valor a pagar: R$ ${valorFinal.toFixed(2)}`;
    resultado.className = "resultado success";
}

// Exercício 3 - Reajuste de Saldo
function calcularReajuste() {
    const saldo = parseFloat(document.getElementById('saldo').value);
    const resultado = document.getElementById('resultado3');
    
    if (isNaN(saldo)) {
        resultado.textContent = "Por favor, insira um valor válido.";
        resultado.className = "resultado error";
        return;
    }
    
    const saldoReajustado = saldo * 1.01;
    resultado.innerHTML = `
        <p>Saldo original: R$ ${saldo.toFixed(2)}</p>
        <p>Saldo reajustado (1%): R$ ${saldoReajustado.toFixed(2)}</p>
    `;
    resultado.className = "resultado success";
}

// Exercício 4 - Cálculos com 3 Números
function calcularMedias() {
    const num1 = parseFloat(document.getElementById('numero1').value);
    const num2 = parseFloat(document.getElementById('numero2').value);
    const num3 = parseFloat(document.getElementById('numero3').value);
    const resultado = document.getElementById('resultado4');
    
    if (isNaN(num1) || isNaN(num2) || isNaN(num3)) {
        resultado.textContent = "Por favor, insira valores válidos para todos os números.";
        resultado.className = "resultado error";
        return;
    }
    
    const mediaAritmetica = (num1 + num2 + num3) / 3;
    const mediaPonderada = (num1 * 3 + num2 * 2 + num3 * 5) / 10;
    const somaMedias = mediaAritmetica + mediaPonderada;
    const mediaDasMedias = somaMedias / 2;
    
    resultado.innerHTML = `
        <p>Média Aritmética: ${mediaAritmetica.toFixed(2)}</p>
        <p>Média Ponderada: ${mediaPonderada.toFixed(2)}</p>
        <p>Soma das Médias: ${somaMedias.toFixed(2)}</p>
        <p>Média das Médias: ${mediaDasMedias.toFixed(2)}</p>
    `;
    resultado.className = "resultado success";
}

// Exercício 5 - Maior entre 2 Valores
function compararValores() {
    const valor1 = parseFloat(document.getElementById('valor1').value);
    const valor2 = parseFloat(document.getElementById('valor2').value);
    const resultado = document.getElementById('resultado5');
    
    if (isNaN(valor1) || isNaN(valor2)) {
        resultado.textContent = "Por favor, insira valores válidos.";
        resultado.className = "resultado error";
        return;
    }
    
    if (valor1 > valor2) {
        resultado.textContent = `O maior valor é: ${valor1}`;
    } else if (valor2 > valor1) {
        resultado.textContent = `O maior valor é: ${valor2}`;
    } else {
        resultado.textContent = "Os valores são iguais.";
    }
    resultado.className = "resultado success";
}

// Exercício 6 - Menor entre 4 Valores
function encontrarMenor() {
    const valor1 = parseFloat(document.getElementById('valor1-6').value);
    const valor2 = parseFloat(document.getElementById('valor2-6').value);
    const valor3 = parseFloat(document.getElementById('valor3-6').value);
    const valor4 = parseFloat(document.getElementById('valor4-6').value);
    const resultado = document.getElementById('resultado6');
    
    if (isNaN(valor1) || isNaN(valor2) || isNaN(valor3) || isNaN(valor4)) {
        resultado.textContent = "Por favor, insira valores válidos para todos os campos.";
        resultado.className = "resultado error";
        return;
    }
    
    const menor = Math.min(valor1, valor2, valor3, valor4);
    resultado.textContent = `O menor valor é: ${menor}`;
    resultado.className = "resultado success";
}

// Exercício 7 - Verificar Número Ímpar
function verificarImpar() {
    const numero = parseInt(document.getElementById('numero').value);
    const resultado = document.getElementById('resultado7');
    
    if (isNaN(numero)) {
        resultado.textContent = "Por favor, insira um número válido.";
        resultado.className = "resultado error";
        return;
    }
    
    if (numero % 2 !== 0) {
        resultado.textContent = `${numero} é ímpar.`;
    } else {
        resultado.textContent = `${numero} não é ímpar.`;
    }
    resultado.className = "resultado success";
}

// Exercício 1 Atividade 2: Variação do Dólar
function calcularVariacoes() {
    const cotacao = parseFloat(document.getElementById('cotacao').value);
    const resultado = document.getElementById('resultado2-1');
    
    if (isNaN(cotacao) || cotacao <= 0) {
        resultado.innerHTML = "<p class='error'>Por favor, insira uma cotação válida</p>";
        return;
    }
    
    const variacoes = [
        { percentual: 1, valor: cotacao * 1.01 },
        { percentual: 2, valor: cotacao * 1.02 },
        { percentual: 5, valor: cotacao * 1.05 },
        { percentual: 10, valor: cotacao * 1.10 }
    ];
    
    let html = "<h3>Resultados:</h3>";
    variacoes.forEach(v => {
        html += `<p>+${v.percentual}% = R$ ${v.valor.toFixed(2)}</p>`;
    });
    
    resultado.innerHTML = html;
}

// Exercício 2 Atividade 2: Cálculo para Omelete
function calcularIngredientes() {
    const pessoas = parseInt(document.getElementById('pessoas').value);
    const resultado = document.getElementById('resultado2-2');
    
    if (isNaN(pessoas) || pessoas <= 0) {
        resultado.innerHTML = "<p class='error'>Por favor, insira um número válido de pessoas</p>";
        return;
    }
    
    const ovos = pessoas * 2;
    const queijo = pessoas * 50;
    
    resultado.innerHTML = `
        <h3>Ingredientes necessários:</h3>
        <p>Ovos: ${ovos} unidades</p>
        <p>Queijo: ${queijo}g</p>
    `;
}

// Exercício 3 Atividade 2: Operações Matemáticas
function calcularOperacoes() {
    const num1 = parseFloat(document.getElementById('numero1-2').value);
    const num2 = parseFloat(document.getElementById('numero2-2').value);
    const resultado = document.getElementById('resultado2-3');
    
    if (isNaN(num1) || isNaN(num2)) {
        resultado.innerHTML = "<p class='error'>Por favor, insira ambos os números</p>";
        return;
    }
    
    resultado.innerHTML = `
        <h3>Resultados:</h3>
        <p>Soma: ${num1 + num2}</p>
        <p>Subtração: ${num1 - num2}</p>
        <p>Multiplicação: ${num1 * num2}</p>
        <p>Divisão: ${(num1 / num2).toFixed(2)}</p>
    `;
}

// Exercício 4 Atividade 2: Pedido de Pizza
function calcularPedido() {
    // Obter sabores
    const sabores = [
        document.getElementById('sabor1').value,
        document.getElementById('sabor2').value,
        document.getElementById('sabor3').value,
        document.getElementById('sabor4').value
    ].filter(sabor => sabor.trim() !== "");
    
    // Obter refrigerantes
    const refrigerantes = parseInt(document.getElementById('refrigerantes').value) || 0;
    
    // Calcular valores
    const valorPizzas = sabores.length * 12;
    const valorRefrigerantes = refrigerantes * 7;
    const total = valorPizzas + valorRefrigerantes;
    
    // Exibir resultado
    const resultado = document.getElementById('resultado2-4');
    resultado.innerHTML = `
        <h3>Seu pedido:</h3>
        <p>Sabores: ${sabores.join(", ")}</p>
        <p>Refrigerantes: ${refrigerantes}</p>
        <h4>Total a pagar: R$ ${total.toFixed(2)}</h4>
    `;
}

// Exercício 1 Atividade 3
function calcularAreaTerreno() {
    const largura = parseFloat(document.getElementById('largura').value);
    const comprimento = parseFloat(document.getElementById('comprimento').value);
    const resultado = document.getElementById('resultado3-1');
    
    if (isNaN(largura) || isNaN(comprimento) || largura <= 0 || comprimento <= 0) {
        resultado.innerHTML = "<p class='error'>Insira valores válidos para largura e comprimento</p>";
        return;
    }
    
    const area = largura * comprimento;
    resultado.innerHTML = `<p>Área do terreno: ${area.toFixed(2)} m²</p>`;
}

// Exercício 2 Atividade 3
function calcularFerraduras() {
    const cavalos = parseInt(document.getElementById('cavalos').value);
    const resultado = document.getElementById('resultado3-2');
    
    if (isNaN(cavalos) || cavalos <= 0) {
        resultado.innerHTML = "<p class='error'>Insira um número válido de cavalos</p>";
        return;
    }
    
    const ferraduras = cavalos * 4;
    resultado.innerHTML = `<p>Quantidade de ferraduras necessárias: ${ferraduras}</p>`;
}

// Exercício 3 Atividade 3
function calcularPadaria() {
    const paes = parseInt(document.getElementById('paes').value) || 0;
    const broas = parseInt(document.getElementById('broas').value) || 0;
    const resultado = document.getElementById('resultado3-3');
    
    if (paes < 0 || broas < 0) {
        resultado.innerHTML = "<p class='error'>Quantidades não podem ser negativas</p>";
        return;
    }
    
    const total = (paes * 0.12) + (broas * 1.50);
    const poupanca = total * 0.1;
    
    resultado.innerHTML = `
        <p>Total arrecadado: R$ ${total.toFixed(2)}</p>
        <p>Valor para poupança (10%): R$ ${poupanca.toFixed(2)}</p>
    `;
}

// Exercício 4 Atividade 3
function calcularDiasVida() {
    const nome = document.getElementById('nome').value.trim();
    const idade = parseInt(document.getElementById('idade').value);
    const resultado = document.getElementById('resultado3-4');
    
    if (nome === "" || isNaN(idade) || idade <= 0) {
        resultado.innerHTML = "<p class='error'>Insira nome e idade válidos</p>";
        return;
    }
    
    const dias = idade * 365;
    resultado.innerHTML = `<p>${nome.toUpperCase()}, VOCÊ JÁ VIVEU ${dias} DIAS</p>`;
}

// Exercício 5 Atividade 3
function calcularCombustivel() {
    const preco = parseFloat(document.getElementById('precoGasolina').value);
    const valor = parseFloat(document.getElementById('valorPagamento').value);
    const resultado = document.getElementById('resultado3-5');
    
    if (isNaN(preco) || isNaN(valor) || preco <= 0 || valor <= 0) {
        resultado.innerHTML = "<p class='error'>Insira valores válidos</p>";
        return;
    }
    
    const litros = valor / preco;
    resultado.innerHTML = `<p>Quantidade de litros: ${litros.toFixed(2)}</p>`;
}

// Exercício 6 Atividade 3
function calcularRefeicao() {
    const peso = parseFloat(document.getElementById('pesoPrato').value);
    const resultado = document.getElementById('resultado3-6');
    
    if (isNaN(peso) || peso <= 0) {
        resultado.innerHTML = "<p class='error'>Insira um peso válido</p>";
        return;
    }
    
    const valor = peso * 12;
    resultado.innerHTML = `<p>Valor a pagar: R$ ${valor.toFixed(2)}</p>`;
}

// Exercício 7 Atividade 3
function calcularDiasAno() {
    const dia = parseInt(document.getElementById('dia').value);
    const mes = parseInt(document.getElementById('mes').value);
    const resultado = document.getElementById('resultado3-7');
    
    if (isNaN(dia) || isNaN(mes) || dia < 1 || dia > 31 || mes < 1 || mes > 12) {
        resultado.innerHTML = "<p class='error'>Insira uma data válida</p>";
        return;
    }
    
    const dias = (mes - 1) * 30 + dia;
    resultado.innerHTML = `<p>Dias desde o início do ano: ${dias}</p>`;
}

// Exercício 8 Atividade 3
function calcularCamisetas() {
    const pequenas = parseInt(document.getElementById('pequenas').value) || 0;
    const medias = parseInt(document.getElementById('medias').value) || 0;
    const grandes = parseInt(document.getElementById('grandes').value) || 0;
    const resultado = document.getElementById('resultado3-8');
    
    if (pequenas < 0 || medias < 0 || grandes < 0) {
        resultado.innerHTML = "<p class='error'>Quantidades não podem ser negativas</p>";
        return;
    }
    
    const total = (pequenas * 10) + (medias * 12) + (grandes * 15);
    resultado.innerHTML = `<p>Valor total arrecadado: R$ ${total.toFixed(2)}</p>`;
}

// Exercício 9 Atividade 3
function calcularDistancia() {
    const x1 = parseFloat(document.getElementById('x1').value);
    const y1 = parseFloat(document.getElementById('y1').value);
    const x2 = parseFloat(document.getElementById('x2').value);
    const y2 = parseFloat(document.getElementById('y2').value);
    const resultado = document.getElementById('resultado3-9');
    
    if (isNaN(x1) || isNaN(y1) || isNaN(x2) || isNaN(y2)) {
        resultado.innerHTML = "<p class='error'>Insira coordenadas válidas</p>";
        return;
    }
    
    const distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    resultado.innerHTML = `<p>Distância entre os pontos: ${distancia.toFixed(2)}</p>`;
}

// Exercício 10 Atividade 3
function converterDiasTrabalho() {
    const dias = parseInt(document.getElementById('diasTrabalho').value);
    const resultado = document.getElementById('resultado3-10');
    
    if (isNaN(dias) || dias <= 0) {
        resultado.innerHTML = "<p class='error'>Insira um número válido de dias</p>";
        return;
    }
    
    const anos = Math.floor(dias / 365);
    const meses = Math.floor((dias % 365) / 30);
    const diasRestantes = dias % 30;
    
    resultado.innerHTML = `
        <p>${dias} dias equivalem a:</p>
        <p>${anos} anos, ${meses} meses e ${diasRestantes} dias</p>
    `;
}

// Exercício 11 Atividade 3
function calcularAjusteSalarial() {
    const salario = parseFloat(document.getElementById('salario').value);
    const resultado = document.getElementById('resultado3-11');
    
    if (isNaN(salario) || salario <= 0) {
        resultado.innerHTML = "<p class='error'>Insira um salário válido</p>";
        return;
    }
    
    const comAumento = salario * 1.15;
    const salarioFinal = comAumento * 0.92;
    
    resultado.innerHTML = `
        <p>Salário inicial: R$ ${salario.toFixed(2)}</p>
        <p>Salário com aumento (15%): R$ ${comAumento.toFixed(2)}</p>
        <p>Salário final (descontados 8%): R$ ${salarioFinal.toFixed(2)}</p>
    `;
}

// Exercício 12 Atividade 3
function decomporNumero() {
    const numero = parseInt(document.getElementById('numero3dig').value);
    const resultado = document.getElementById('resultado3-12');
    
    if (isNaN(numero) || numero < 0 || numero > 999) {
        resultado.innerHTML = "<p class='error'>Insira um número entre 0 e 999</p>";
        return;
    }
    
    const centena = Math.floor(numero / 100);
    const dezena = Math.floor((numero % 100) / 10);
    const unidade = numero % 10;
    
    resultado.innerHTML = `
        <p>CENTENA = ${centena}</p>
        <p>DEZENA = ${dezena}</p>
        <p>UNIDADE = ${unidade}</p>
    `;
}

// Exercício 13 Atividade 3
function calcularAreaPizza() {
    const raio = parseFloat(document.getElementById('raioPizza').value);
    const resultado = document.getElementById('resultado3-13');
    
    if (isNaN(raio) || raio <= 0) {
        resultado.innerHTML = "<p class='error'>Insira um raio válido</p>";
        return;
    }
    
    const area = 3.14 * Math.pow(raio, 2);
    resultado.innerHTML = `<p>Área da pizza: ${area.toFixed(2)} cm²</p>`;
}

// Exercício 14 Atividade 3
function dividirConta() {
    const total = parseFloat(document.getElementById('totalConta').value);
    const resultado = document.getElementById('resultado3-14');
    
    if (isNaN(total) || total <= 0) {
        resultado.innerHTML = "<p class='error'>Insira um valor válido</p>";
        return;
    }
    
    const parte = total / 3;
    const carlos = Math.floor(parte);
    const andre = Math.floor(parte);
    const felipe = total - carlos - andre;
    
    resultado.innerHTML = `
        <p>Carlos paga: R$ ${carlos.toFixed(2)}</p>
        <p>André paga: R$ ${andre.toFixed(2)}</p>
        <p>Felipe paga: R$ ${felipe.toFixed(2)}</p>
    `;
}