document.getElementById("btnSomar").onclick = function () {
    let numero1 = parseFloat(document.getElementById("numero1").value);
    let numero2 = parseFloat(document.getElementById("numero2").value);
    let resultado = numero1 + numero2;
    document.getElementById("resultadoSoma").textContent = "Resultado: " + resultado;
};
document.getElementById("btnTroco").onclick = function () {
    let valorPago = parseFloat(document.getElementById("valorPago").value);
    let precoProduto = parseFloat(document.getElementById("precoProduto").value);
    let troco = valorPago - precoProduto;

    if (troco < 0) {
        document.getElementById("resultadoTroco").textContent = "Valor pago é insuficiente.";
    } else {
        document.getElementById("resultadoTroco").textContent = "Troco: R$ " + troco.toFixed(2);
    }
};

let titulo = document.querySelector("#titulo");
let campoTexto = document.querySelector("#campoTexto");
let btTrocarTexto = document.querySelector("#btTrocarTexto");

function alterarTexto() {
    let textoDigitado = campoTexto.value;
    titulo.textContent = textoDigitado;
}

btTrocarTexto.onclick = function () {
    alterarTexto();
};


function calcularValor() {
    const precoQuilo = parseFloat(document.getElementById('precoQuilo').value);
    const quantidadeQuilos = parseFloat(document.getElementById('quantidadeQuilos').value);
  
    if (isNaN(precoQuilo) || isNaN(quantidadeQuilos)) {
      document.getElementById('resultado').innerText = 'Por favor, insira valores válidos.';
      return;
    }
  
    const valorTotal = precoQuilo * quantidadeQuilos;
    document.getElementById('resultado').innerText = `Valor a pagar: R$ ${valorTotal.toFixed(2)}`;
  }
  



  function reajustarSaldo() {
    const saldo = parseFloat(document.getElementById('saldo').value);
  
    if (isNaN(saldo)) {
      document.getElementById('resultado3').innerText = 'Digite um valor válido.';
      return;
    }
  
    const saldoReajustado = saldo * 1.01;
    document.getElementById('resultado3').innerText = `Saldo com reajuste de 1%: R$ ${saldoReajustado.toFixed(2)}`;
  }
  


  function calcularMedias() {
    const n1 = parseFloat(document.getElementById('num1').value);
    const n2 = parseFloat(document.getElementById('num2').value);
    const n3 = parseFloat(document.getElementById('num3').value);
  
    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) {
      document.getElementById('resultadoMedias').innerText = 'Por favor, preencha os três números corretamente.';
      return;
    }
  
    const mediaAritmetica = (n1 + n2 + n3) / 3;
    const mediaPonderada = (n1 * 3 + n2 * 2 + n3 * 5) / 10;
    const somaMedias = mediaAritmetica + mediaPonderada;
    const mediaDasMedias = somaMedias / 2;
  
    document.getElementById('resultadoMedias').innerHTML = `
      a) Média Aritmética: ${mediaAritmetica.toFixed(2)}<br>
      b) Média Ponderada (3, 2, 5): ${mediaPonderada.toFixed(2)}<br>
      b) Soma das médias: ${somaMedias.toFixed(2)}<br>
      c) Média das médias: ${mediaDasMedias.toFixed(2)}
    `;
  }
  